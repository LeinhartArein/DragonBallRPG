====================================================
----------------------Readme for Goku By Sabre-------------------------------
====================================================

This is a budget readme, so ill just get right onto the
______________________________________________________________
=====================
--MOVES-----------------------
_______________________________________________________________


-----Teh Basiques:
a = Weak Kick 
b = Medium Kick
c = Strong Kick (away launcher)
x = Weak Punch
y = Medium Punch
z = Strong Punch (air launcher)

Dashing: 
foward, back, up, down, in air and on ground

Air Moves:
a = Weak Kick
b = Medium Kick
c = Strong Kick (up launcher)
x = Weak Punch
y = Medium Punch
z = Strong Punch (down bounce launcher)



-----Specials:

Hold c = Charges up his strong kick, knocking the opponent further
 -----NOT DONE----Hold z = Charge the uppercut, at full power it resembles a shoyruken.------NOT DONE-----

D, DB, B, kick = Spinning Kick - Another away launcher
D, DF, F, punch = KI Shot - up to 5 in a row

4 More to come...


-----Air Specials:

Back + kick = Spin Kick - Same as the ground 1

1 More to Come...

-----Supers:

D, DB, B, F, punch = Flying Fists
D, DF, F, D, DF, F, x = Kamehameha - up or  (not done)down

2 More to Come....


-----Hypers:

Havent done any yet.
4 planned out though


------------------------THANKS TO-------------------------------
Naruto = For doing most of the sprites and then ditching my ass.
Elecbyte = For Half-Assing Mugen and then ditching my ass.
Rouhei = For Assing the other half of Mugen.
Me = For Being So Damn Hot.
Whoever helped Naruto with the sprites = You know who you are. I don't.

-----------------------COMING SOON------------------------------
Look at the ZGTeam Post, Im lazy.

